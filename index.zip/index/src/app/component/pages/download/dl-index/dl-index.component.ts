import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dl-index',
  templateUrl: './dl-index.component.html',
  styleUrls: ['./dl-index.component.css']
})
export class DlIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

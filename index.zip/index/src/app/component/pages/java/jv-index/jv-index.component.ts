import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jv-index',
  templateUrl: './jv-index.component.html',
  styleUrls: ['./jv-index.component.css']
})
export class JvIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

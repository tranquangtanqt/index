import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spr-begin',
  templateUrl: './spr-begin.component.html',
  styleUrls: ['./spr-begin.component.css']
})
export class SprBeginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css3d-card-flip-animation',
  templateUrl: './css3d-card-flip-animation.component.html',
  styleUrls: ['./css3d-card-flip-animation.component.css']
})
export class Css3dCardFlipAnimationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

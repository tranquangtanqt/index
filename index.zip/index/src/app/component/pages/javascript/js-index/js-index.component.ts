import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-js-index',
  templateUrl: './js-index.component.html',
  styleUrls: ['./js-index.component.css']
})
export class JsIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

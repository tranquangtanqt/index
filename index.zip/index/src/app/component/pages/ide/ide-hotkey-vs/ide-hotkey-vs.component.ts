import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ide-hotkey-vs',
  templateUrl: './ide-hotkey-vs.component.html',
  styleUrls: ['./ide-hotkey-vs.component.css']
})
export class IdeHotkeyVsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

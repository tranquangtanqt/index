import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ide-index',
  templateUrl: './ide-index.component.html',
  styleUrls: ['./ide-index.component.css']
})
export class IdeIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

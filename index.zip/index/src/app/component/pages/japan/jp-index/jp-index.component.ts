import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-jp-index',
  templateUrl: './jp-index.component.html',
  styleUrls: ['./jp-index.component.css']
})
export class JpIndexComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
  	
  }

  

}
